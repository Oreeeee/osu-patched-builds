Collection of osu! 2014 test/cuttingedge builds modified
to not require supporter or connecting to a private server.

Instructions:
1. Put the exe to the corresponding game build files.
2. Launch the exe.

- Made by Oreeeee