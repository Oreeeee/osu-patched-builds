osu! April Fools 2015 builds modified
to show osu!coin stuff without online connection.

Tutorial:
1. Copy the exe file to the game files of
the appriopiate build.
2. Run the game.

WARNING:
Make sure that the exe is named osu!.exe OR
that you are starting the game with -go command-line
argument. Otherwise, the updater will restart and
start the unmodified executable.


- Made by Oreeeee