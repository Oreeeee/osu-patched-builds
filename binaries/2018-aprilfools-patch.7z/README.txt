osu! April Fools 2018 clients (Beta and Cutting Edge)
patched to load the "spinning logo" payload
no matter the system time.

Tutorial:
1. Copy the exe to the corresponding game version
files.
2. Launch the game.

DISCLAIMER:
You HAVE to name the patched executable osu!.exe,
otherwise the game will not launch.


- Made by Oreeeee