Patched osu! b1807 (April Fools 2011) client
that always triggers the payload, which originally
required the system time to be set to 2011-04-01.

Tutorial:
1. Copy the exe file to b1807 game files.
2. Start osu!patched.exe.

- Made by Oreeeee